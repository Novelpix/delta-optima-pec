1. Déploie ce dossier sur Netlify.
2. Mets ta Publishable Key dans app.js.
3. Exécute supabase_schema.sql dans Supabase.
4. Crée un bucket pec-photos.
5. C'est prêt.
